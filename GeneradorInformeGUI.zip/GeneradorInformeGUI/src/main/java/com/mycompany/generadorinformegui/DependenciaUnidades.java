/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.generadorinformegui;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author USER
 */
public class DependenciaUnidades {
     DuplicarPaginas nueva= new DuplicarPaginas();
    
    public void duplicar(XSSFWorkbook libro, int totalUnidades) {
        
    if (totalUnidades <= 1) return;

    for (int i = 2; i <= totalUnidades; i++) {
        nueva.DuplicarFilasRango(libro,65,126, i);
    }
}

     
     
     
}
