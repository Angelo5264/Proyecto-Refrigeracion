/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.generadorinformegui;

import java.io.File;
import javax.swing.JOptionPane;

/**
 *
 * @author USER
 */
public class EliminarImagen {
    
  public void eliminarImagenesAnteriores() {
    String[] carpetas = {
        "D:\\AlmacenImagenes1\\",
        "D:\\AlmacenImagenes2\\",
        "D:\\AlmacenImagenes3\\",
        "D:\\AlmacenImagenes4\\",
        "D:\\AlmacenImagenes5\\",
        "D:\\AlmacenImagenes6\\",
        "D:\\AlmacenImagenes7\\",
        "D:\\AlmacenImagenes8\\",
        "D:\\AlmacenImagenes9\\",
        "D:\\AlmacenImagenes10\\",
           
    };

    boolean seEliminoAlgo = false;

    for (String ruta : carpetas) {
        File directorio = new File(ruta);

        if (directorio.exists() && directorio.isDirectory()) {
            File[] archivos = directorio.listFiles((dir, name) ->
                name.toLowerCase().endsWith(".jpg") ||
                name.toLowerCase().endsWith(".jpeg") ||
                name.toLowerCase().endsWith(".png")
            );

            if (archivos != null && archivos.length > 0) {
                for (File archivo : archivos) {
                    if (archivo.delete()) {
                        System.out.println("Eliminado: " + archivo.getName());
                        seEliminoAlgo = true;
                    } else {
                        System.out.println("No se pudo eliminar: " + archivo.getName());
                    }
                }
            }
        } else {
            System.out.println("Carpeta no válida o no existe: " + ruta);
        }
    }

    if (seEliminoAlgo) {
        JOptionPane.showMessageDialog(null, "Imágenes eliminadas correctamente.");
    } else {
        JOptionPane.showMessageDialog(null, "No se encontraron imágenes para eliminar.");
    }
}
}
