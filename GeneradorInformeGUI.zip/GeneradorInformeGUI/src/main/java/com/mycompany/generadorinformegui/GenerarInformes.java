/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.generadorinformegui;

import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;
  import java.io.*;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import javax.swing.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


/**
 *
 * @author USER
 */
public class GenerarInformes {
           

    

    public void generarInforme(
        JTextField fecha,
        JTextField direccion,
        JTextField Tienda,
        JComboBox<String> tecnico,
        JComboBox<String> ob1,
        JComboBox<String> ob2,
        JComboBox<String> ob3,
        JComboBox<String> re1,
        JComboBox<String> re2,
        JComboBox<String> re3,
        JComboBox<String> unidades,
        JComboBox<String> marca,
        JComboBox<String> temperatura
    ) {
        
     
        
       try {
    // 1. Crear una copia temporal de la plantilla original
    File plantillaOriginal = new File("C:/Users/USER/Documents/NetBeansProjects/Plantilla.xlsx");
    File plantillaTemp = new File("C:/Users/USER/Documents/NetBeansProjects/PlantillaTemp.xlsx");
    Files.copy(plantillaOriginal.toPath(), plantillaTemp.toPath(), StandardCopyOption.REPLACE_EXISTING);

    // 2. Trabajar sobre la copia
    FileInputStream fis = new FileInputStream(plantillaTemp);
    XSSFWorkbook libro = new XSSFWorkbook(fis);

    // 3. Inserción de imágenes
    InsertarImagen.insertarImagenDesdeCarpeta(libro, "[Placa]", "P.jpg", 150, 100);
    InsertarImagen.insertarImagenDesdeCarpeta(libro, "[Foto]", "F.jpg", 150, 100);
    InsertarImagen.insertarImagenDesdeCarpeta(libro, "[Pro1]", "P1.jpg", 150, 100);
    InsertarImagen.insertarImagenDesdeCarpeta(libro, "[Pro2]", "P2.jpg", 150, 100);
    InsertarImagen.insertarImagenDesdeCarpeta(libro, "[Pro3]", "P3.jpg", 150, 100);
    InsertarImagen.insertarImagenDesdeCarpeta(libro, "[ParametroV]", "V.jpg", 150, 100);
    InsertarImagen.insertarImagenDesdeCarpeta(libro, "[ParametroA]", "A.jpg", 150, 100);
    InsertarImagen.insertarImagenDesdeCarpeta(libro, "[ParametroT]", "T.jpg", 150, 100);
    InsertarImagen.insertarImagenDesdeCarpeta(libro, "[LimpiezaA]", "LA.jpg", 150, 100);
    InsertarImagen.insertarImagenDesdeCarpeta(libro, "[LimpiezaD]", "LD.jpg", 150, 100);

    // 4. Reemplazo de texto
    Map<String, String> reemplazos = new HashMap<>();
    reemplazos.put("{Fecha}", fecha.getText());
    reemplazos.put("{Direccion}", direccion.getText());
    reemplazos.put("{Tienda}", Tienda.getText());
    reemplazos.put("{Tecnico encargado}", String.valueOf(tecnico.getSelectedItem()));
    reemplazos.put("{Observacion_1}", String.valueOf(ob1.getSelectedItem()));
    reemplazos.put("{Observacion_2}", String.valueOf(ob2.getSelectedItem()));
    reemplazos.put("{Observacion_3}", String.valueOf(ob3.getSelectedItem()));
    reemplazos.put("{Reco_1}", String.valueOf(re1.getSelectedItem()));
    reemplazos.put("{Reco_2}", String.valueOf(re2.getSelectedItem()));
    reemplazos.put("{Reco_3}", String.valueOf(re3.getSelectedItem()));
    reemplazos.put("{unidades de equipos}", String.valueOf(unidades.getSelectedItem()));
    reemplazos.put("{Nombre}", String.valueOf(marca.getSelectedItem()));
    reemplazos.put("{MEDIA/BAJA}", String.valueOf(temperatura.getSelectedItem()));

    RemplazarTexto.reemplazarTextoEnExcel(libro, reemplazos);

    // 5. Guardar la copia modificada temporalmente
    FileOutputStream fos = new FileOutputStream(plantillaTemp);
    libro.write(fos);
    fos.close();
    libro.close();
    fis.close();

    JOptionPane.showMessageDialog(null, "Informe generado correctamente.");

    // 6. Guardar en ubicación personalizada
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setDialogTitle("Guardar informe como");
    int seleccion = fileChooser.showSaveDialog(null);

    if (seleccion == JFileChooser.APPROVE_OPTION) {
        File destino = fileChooser.getSelectedFile();
        if (!destino.getName().toLowerCase().endsWith(".xlsx")) {
            destino = new File(destino.getAbsolutePath() + ".xlsx");
        }

        Files.copy(plantillaTemp.toPath(), destino.toPath(), StandardCopyOption.REPLACE_EXISTING);
        JOptionPane.showMessageDialog(null, "Informe generado en:\n" + destino.getAbsolutePath());
    }

    // 7. Eliminar la copia temporal (opcional)
    plantillaTemp.delete();

} catch (Exception e) {
    e.printStackTrace();
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
}

} 
    
} 