/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.generadorinformegui;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author USER
 */
public class DuplicarPaginas {
    CopiarContenido conte=new CopiarContenido();
    
   public void DuplicarFilasRango(XSSFWorkbook libro, int filaInicio, int filaFin, int unidadNueva) {
    Sheet hoja = libro.getSheetAt(0);
    CopiarContenido conte = new CopiarContenido(); // Tu clase para copiar celdas

    int nuevaFilaInicio = hoja.getLastRowNum() + 2; // Deja espacio

    for (int i = filaInicio; i <= filaFin; i++) {
        Row filaOriginal = hoja.getRow(i);
        Row nuevaFila = hoja.createRow(nuevaFilaInicio + (i - filaInicio));

        if (filaOriginal != null) {
            nuevaFila.setHeight(filaOriginal.getHeight()); // Copiar altura de la fila

            for (int j = 0; j < filaOriginal.getLastCellNum(); j++) {
                Cell celdaOriginal = filaOriginal.getCell(j);
                if (celdaOriginal != null) {
                    Cell nuevaCelda = nuevaFila.createCell(j);
                    conte.copiarContenidoCelda(celdaOriginal, nuevaCelda); // Tu método
                }
            }
        }
     }
    }
    }