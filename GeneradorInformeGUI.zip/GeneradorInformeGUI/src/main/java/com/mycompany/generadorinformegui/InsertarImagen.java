/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.generadorinformegui;

import java.io.FileInputStream;
import java.io.InputStream;
import javax.swing.JOptionPane;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.ClientAnchor;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Drawing;
import org.apache.poi.ss.usermodel.Picture;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.util.IOUtils;
import org.apache.poi.util.Units;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author USER
 */
public class InsertarImagen {
    
     public static void insertarImagenDesdeCarpeta(XSSFWorkbook libro, String marcador, String nombreArchivo, int anchoPx, int altoPx) {
    String rutaBase = "D:\\AlmacenImagenes1\\";
    String rutaCompleta = rutaBase + nombreArchivo;

    try {
        for (org.apache.poi.ss.usermodel.Sheet hoja : libro) {
            for (Row fila : hoja) {
                for (Cell celda : fila) {
                    if (celda.getCellType() == CellType.STRING) {
                        String texto = celda.getStringCellValue();
                        if (texto != null && texto.contains(marcador)) {

                            // Reemplazar marcador por texto vacío o lo que desees
                            celda.setCellValue(texto.replace(marcador, "").trim());

                            // Cargar imagen
                            InputStream inputStream = new FileInputStream(rutaCompleta);
                            byte[] bytes = IOUtils.toByteArray(inputStream);
                            int tipoImagen = nombreArchivo.toLowerCase().endsWith(".png") ?
                                    Workbook.PICTURE_TYPE_PNG : Workbook.PICTURE_TYPE_JPEG;
                            int pictureIdx = libro.addPicture(bytes, tipoImagen);
                            inputStream.close();

                            // Preparar dibujo
            CreationHelper helper = libro.getCreationHelper();
            Drawing<?> drawing = hoja.createDrawingPatriarch();
            ClientAnchor anchor = helper.createClientAnchor();

// Posicionar la imagen en la celda
            anchor.setCol1(celda.getColumnIndex());
            anchor.setRow1(celda.getRowIndex());
            anchor.setCol2(celda.getColumnIndex() + 4); // ocupa 4 columnas
            anchor.setRow2(celda.getRowIndex() + 6);     // ocupa 6 filas

            anchor.setDx1(0); // desplazamiento inicial desde esquina superior izquierda
            anchor.setDy1(0);
            anchor.setAnchorType(ClientAnchor.AnchorType.MOVE_AND_RESIZE);

// Insertar imagen
            Picture pict = drawing.createPicture(anchor, pictureIdx);

// Redimensionar automáticamente dentro del área asignada
            pict.resize(0.8);  // Esto adapta la imagen al área entre Col1-2 y Row1-2

            return; // Imagen insertada, salir
                        }
                    }
                }
            }
        }

    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error al insertar imagen en Excel " + nombreArchivo + ":\n" + e.getMessage());
    }
}  
     
}
