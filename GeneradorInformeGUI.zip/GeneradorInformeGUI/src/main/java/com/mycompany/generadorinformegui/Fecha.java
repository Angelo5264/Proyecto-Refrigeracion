/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.generadorinformegui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javax.swing.JTextField;

/**
 *
 * @author USER
 */
public class Fecha {
     public void ponerFechaActualEnCampo(JTextField fecha) {
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    String fechaActual = LocalDate.now().format(formatter);
    fecha.setText(fechaActual);
}

}
