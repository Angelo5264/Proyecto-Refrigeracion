/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.generadorinformegui;

import java.util.Map;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author USER
 */
public class RemplazarTexto {
    
public static void reemplazarTextoEnExcel(XSSFWorkbook libro, Map<String, String> reemplazos) {
    for (org.apache.poi.ss.usermodel.Sheet hoja : libro) {
        for (Row fila : hoja) {
            for (Cell celda : fila) {
                if (celda.getCellType() == CellType.STRING) {
                    String texto = celda.getStringCellValue();
                    for (Map.Entry<String, String> entrada : reemplazos.entrySet()) {
                        if (texto.contains(entrada.getKey())) {
                            texto = texto.replace(entrada.getKey(), entrada.getValue());
                        }
                    }
                    celda.setCellValue(texto);
                }
            }
        }
    }
}
}
