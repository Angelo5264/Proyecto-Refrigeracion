/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.generadorinformegui;

import org.apache.poi.ss.usermodel.Cell;
import static org.apache.poi.ss.usermodel.CellType.BOOLEAN;
import static org.apache.poi.ss.usermodel.CellType.FORMULA;
import static org.apache.poi.ss.usermodel.CellType.NUMERIC;
import static org.apache.poi.ss.usermodel.CellType.STRING;

/**
 *
 * @author USER
 */
public class CopiarContenido {
    
void copiarContenidoCelda(Cell original, Cell destino) {
    destino.setCellStyle(original.getCellStyle());
    switch (original.getCellType()) {
        case STRING:
            destino.setCellValue(original.getStringCellValue());
            break;
        case NUMERIC:
            destino.setCellValue(original.getNumericCellValue());
            break;
        case BOOLEAN:
            destino.setCellValue(original.getBooleanCellValue());
            break;
        case FORMULA:
            destino.setCellFormula(original.getCellFormula());
            break;
        default:
            break;
    }
}

}
